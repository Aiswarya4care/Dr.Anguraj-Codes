library(xlsx)
library(dplyr)
gene_list <- as.vector(t(unique(read.csv("E:/MSc Bioinformatics Semester IV/Identification of Molecular Signatures in Oral Cancer from Whole Exome Sequencing Data Using Computational Approach/Work/Filtration/unique_genes.csv"))))
loc1 <- "E:/MSc Bioinformatics Semester IV/Identification of Molecular Signatures in Oral Cancer from Whole Exome Sequencing Data Using Computational Approach//Work/Filtration/IN-423-THDB-F2_merged_output.csv"
loc2 <- "E:/MSc Bioinformatics Semester IV/Identification of Molecular Signatures in Oral Cancer from Whole Exome Sequencing Data Using Computational Approach//Work/Filtration/IN-423-THDB-F2-REL-CA_merged_output.csv"
loc3 <- "E:/MSc Bioinformatics Semester IV/Identification of Molecular Signatures in Oral Cancer from Whole Exome Sequencing Data Using Computational Approach//Work/Filtration/IN-423-TJZD-F2-RE-CA_merged_output.csv"
loc4 <- "E:/MSc Bioinformatics Semester IV/Identification of Molecular Signatures in Oral Cancer from Whole Exome Sequencing Data Using Computational Approach//Work/Filtration/IN-423-TKKA-F-RE-CA_merged_output.csv"
loc5 <- "E:/MSc Bioinformatics Semester IV/Identification of Molecular Signatures in Oral Cancer from Whole Exome Sequencing Data Using Computational Approach//Work/Filtration/IN-423-TKQD-F-RE-CA_merged_output.csv"
in_paths <- c(loc1,loc2,loc3,loc4,loc5)
for (loc in in_paths) {
  print(loc)
  problem <- read.csv(loc)
  problem <- problem %>% rename("FkG" = "Func.knownGene", "EFkG" = "ExonicFunc.knownGene", "C13Q" = "CADD13_PHRED", "InterVar" = "InterVar_automated", "CancerVar" = "CancerVar..CancerVar.and.Evidence", "pop_f1" = "esp6500siv2_all", "pop_f2" = "ExAC_ALL", "pop_f3" = "ExAC_SAS", "pop_f4" = "AF", "pop_f5" = "AF_sas", "pop_f6" = "X1000g2015aug_all", "pop_f7" = "X1000g2015aug_SAS")
  print(nrow(problem))
  filter1 <- problem[(problem$FkG %in% c("exonic","splicing","exonic;splicing")),]
  print(nrow(filter1))
  filter2 <- filter1[!(filter1$EFkG %in% c(".","synonymous SNV")),]
  print(nrow(filter2))
  filter3 <- filter2[(filter2$C13Q == "." | filter2$C13Q >=20),]
  print(nrow(filter3))
  filter4 <- filter3[!grepl("benign",filter3$CancerVar),]
  print(nrow(filter4))
  filter5 <- filter4[!(grepl("Benign",filter4$InterVar) | grepl("Likely_benign",filter4$InterVar)),]
  print(nrow(filter5))
  filter6 <- filter5[(filter5$pop_f1 == "." | as.numeric(filter5$pop_f1) <= 0.01),]
  print(nrow(filter6))
  filter7 <- filter6[(filter6$pop_f2 == "." | as.numeric(filter6$pop_f2) <= 0.01),]
  print(nrow(filter7))
  filter8 <- filter7[(filter7$pop_f3 == "." | as.numeric(filter7$pop_f3) <= 0.01),]
  print(nrow(filter8))
  filter9 <- filter8[(filter8$pop_f4 == "." | as.numeric(filter8$pop_f4) <= 0.01),]
  print(nrow(filter9))
  filter10 <- filter9[(filter9$pop_f5 == "." | as.numeric(filter9$pop_f5) <= 0.01),]
  print(nrow(filter10))
  filter11 <- filter10[(filter10$pop_f6 == "." | as.numeric(filter10$pop_f6) <= 0.01),]
  print(nrow(filter11))
  filter12 <- filter11[(filter11$pop_f7 == "." | as.numeric(filter11$pop_f7) <= 0.01),]
  print(nrow(filter12))
  finale <- filter12[(filter12$Ref.Gene_x %in% gene_list),]
  print(nrow(finale))
}